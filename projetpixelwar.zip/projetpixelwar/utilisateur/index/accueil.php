<?php if (session_status() === PHP_SESSION_NONE) {
session_start();
}

if (!isset($_SESSION['user_id'])) {
$_SESSION['user_id'] = 0;
}?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PIXEL WAR</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../navbar/style.css">
</head>
<body>

<?php include '../navbar/navbar.php' ?>
<div class="container">
    <a href="../login/login.php" class="button">Se connecter</a>
    <a href="../register/register.php" class="button">Créer un compte</a>
</div>
<!--<a href="../../grille/selectgrille.php">-->
<!--    <img src="zidane.jpg" style="max-width: 200%; height: auto;">-->
<!--</a>-->

</body>
</html>
