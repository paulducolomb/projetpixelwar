<?php
session_start();


$conn = new mysqli("localhost", "test", "test", "projetpixelwar");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);

    $sql = "SELECT * FROM utilisateur WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        $user = $result->fetch_assoc();
        if (password_verify($password, $user['mot_de_passe']))
        {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['pseudonyme'];
            header("Location: ../../grille/selectgrille.php");
            exit();
        } else {
            echo "Mot de passe incorrect.";
        }
    } else {
        echo "Aucun utilisateur trouvé avec cet email.";
    }
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pixel War</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../navbar/style.css">
</head>
<body>
<?php include '../navbar/navbar.php'; ?>
<form action="login.php" method="post">
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="password">Mot de passe:</label>
    <input type="password" id="password" name="password" required>

    <button type="submit">Se connecter</button>
    <a href="../register/register.php" type="submit">créer un compte </a>
</form>
</body>
</html>