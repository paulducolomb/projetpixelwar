<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

//supprimer la session en cours lors de l'appui sur disconnect
if (isset($_POST['disconnect'])) {
    session_destroy();
    header("Location: ../../../projetpixelwar/utilisateur/index/accueil.php");
    exit();
}
?>

<nav class="navbar">
    <div class="navbar-container">
        <a href="../../../projetpixelwar/grille/selectgrille.php" class="navbar-logo">PIXEL WAR</a>

        <ul class="navbar-menu">
            <li><a href="../../../projetpixelwar/grille/selectgrille.php" class="navbar-link">Accueil</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
<!--            //récupération du pseudo de l'utilisateur et pseudo par défaut quand il n'y a plus d'utilisatuer-->
                <li><a href="#" class="navbar-link"><?= isset($_SESSION['username']) ? $_SESSION['username'] : 'Utilisateur'; ?></a></li>
<!--
                        //afficher le bouton disconnect avec une méthode post
<li>-->
<!--                    <form method="POST" style="display:inline;">-->
<!--                        <button type="submit" name="disconnect" class="navbar-link" style="background:none;border:none;color:inherit;cursor:pointer;">Déconnexion</button>-->
<!--                    </form>-->
<!--                </li>-->
            <?php else: ?>
                <li><a href="../../../projetpixelwar/utilisateur/login/login.php" class="navbar-link">Se connecter</a></li>
                <li><a href="../../../projetpixelwar/utilisateur/register/register.php" class="navbar-link">Créer un compte</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
