<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Connexion à la base de données
$conn = new mysqli("localhost", "test", "test", "projetpixelwar");
//chiffrement du mdp pour ne pas le stocker en clair dans la bdd
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($conn->real_escape_string($_POST['password']), PASSWORD_BCRYPT);
    $username = $conn->real_escape_string($_POST['username']);

    $sql = "INSERT INTO utilisateur (email, mot_de_passe, pseudonyme) VALUES ('$email', '$password', '$username')";
    //redirection vers la page de connection pour etre sur que l'utilisateur connait bien son mdp
    if ($conn->query($sql) === TRUE) {
        echo "Compte créé avec succès.";
        header("Location: ../login/login.php");

    } else {
        echo "Erreur: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pixel War</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../navbar/style.css">
</head>
<body>
<?php include '../navbar/navbar.php'; ?>

<form action="register.php" method="post">
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="password">Mot de passe:</label>
    <input type="password" id="password" name="password" required>

    <label for="username">Pseudonyme:</label>
    <input type="text" id="username" name="username" required>

    <button type="submit">Créer un compte</button>
    <a href="../login/login.php"  type="submit">Se connecter</a>
</form>
</body>
</html>

