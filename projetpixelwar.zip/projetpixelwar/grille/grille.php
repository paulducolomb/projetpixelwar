<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
//deconnection
if (isset($_POST['disconnect'])) {
    session_destroy();
    header("Location: ../../../projetpixelwar/utilisateur/index/accueil.php");
    exit();
}

$conn = new mysqli("localhost", "test", "test", "projetpixelwar");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$grille_id = $_GET['id'];

$pixels = $conn->query("SELECT * FROM pixel WHERE grille_id='$grille_id'");
//envoie données
$pixel_data = [];
while ($row = $pixels->fetch_assoc()) {
    $pixel_data[$row['position_x']][$row['position_y']] = [
        'couleur' => $row['couleur'],
        'proprietaire_id' => $row['proprietaire_id']
    ];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grille PIXEL WAR</title>
    <link rel="stylesheet" href="grille.css">
    <link rel="stylesheet" href="../utilisateur/navbar/style.css">
    <script>
        const grilleId = <?= $grille_id ?>;
        const pixelData = <?= json_encode($pixel_data) ?>;
    </script>
    <script src="grille.js" defer></script>
</head>
<body>

<?php include '../utilisateur/navbar/navbar.php'; ?>
<div class="disconnect">
    <form method="POST">
        <input type="submit" id="disconnect" name="disconnect" value="Déconnecter">
    </form>
</div>
<div id="grid">
    <!-- création de la grille 30x30-->
    <?php
    for ($y = 0; $y < 30; $y++) {
        echo "<div class='row'>";
        for ($x = 0; $x < 30; $x++) {
            $couleur = isset($pixel_data[$x][$y]) ? $pixel_data[$x][$y]['couleur'] : '#FFFFFF';
            echo "<div class='pixel' id='pixel-$x-$y' style='background-color: $couleur;'></div>";
        }
        echo "</div>";
    }
    ?>
</div>
<!--affichage du choix des couleurs-->
<div id="color-picker">
    <div class="color-choice" style="background-color: #FF0000;"></div>
    <div class="color-choice" style="background-color: #00FF00;"></div>
    <div class="color-choice" style="background-color: #0000FF;"></div>
    <div class="color-choice" style="background-color: #FFFF00;"></div>
    <div class="color-choice" style="background-color: #FF00FF;"></div>
    <div class="color-choice" style="background-color: #00FFFF;"></div>
</div>
</body>
</html>
