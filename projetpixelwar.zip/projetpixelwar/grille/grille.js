// let selectedColor = '#FFFF00'; // Default color

function changeColor(event) {
    const pixelId = event.target.id;
    const [prefix, x, y] = pixelId.split('-');


// Envoyer la mise à jour de la couleur au serveur
    fetch('majpixel.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            grille_id: grilleId,
            position_x: x,
            position_y: y,
            couleur: selectedColor,
        }),

    })
        // Convertir la réponse en JSON
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                event.target.style.backgroundColor = selectedColor; //maj couleur
            } else {
                console.error('Error updating pixel:', data.error); //gérer les erreurs
                console.log('SQL Query:', data.sql);
            }
        })
}


function selectColor(event) {
    selectedColor = event.target.style.backgroundColor;
}
// selection pixel
window.onload = function() {
    const pixels = document.querySelectorAll('.pixel');
    pixels.forEach(pixel => {
        pixel.addEventListener('click', changeColor);
    });
//selection couleur
    const colorChoices = document.querySelectorAll('.color-choice');
    colorChoices.forEach(colorChoice => {
        colorChoice.addEventListener('click', selectColor);
    });
//initialiser les couleurs des pixels
    for (let x in pixelData) {
        for (let y in pixelData[x]) {
            document.getElementById(`pixel-${x}-${y}`).style.backgroundColor = pixelData[x][y].couleur;
        }
    }
}
