<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$conn = new mysqli("localhost", "test", "test", "projetpixelwar");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $conn->real_escape_string($_POST['nom']);
    $sql = "INSERT INTO grille (nom) VALUES ('$nom')";

    if ($conn->query($sql) === TRUE) {
        header("Location: grille.php?id=" . $conn->insert_id);
    } else {
        echo "Erreur: " . $sql . "<br>" . $conn->error;
    }
}

$grilles = $conn->query("SELECT id, nom FROM grille");
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PIXEL WAR - Sélectionner ou créer une grille</title>
    <link rel="stylesheet" href="../utilisateur/navbar/style.css">
    <link rel="stylesheet" href="grille.css">
</head>
<body>
<?php include '../utilisateur/navbar/navbar.php'; ?>

<div class="disconnect">
    <form method="POST">
        <input type="submit" id="disconnect" name="disconnect" value="Déconnecter">
    </form>
</div>
<form action="selectgrille.php" method="post">
    <label for="nom">Nom de la nouvelle grille:</label>
    <input type="text" id="nom" name="nom" required>
    <button type="submit">Créer une nouvelle grille</button>
</form>

<h2>Grilles</h2>
<listegrille>
<!--    transfert de l'id et du nom de la grille -->
    <?php while ($row = $grilles->fetch_assoc()): ?>
        <li><a href="grille.php?id=<?= $row['id'] ?>"><?= $row['nom'] ?></a></li>
    <?php endwhile; ?>
</listegrille>
</body>
</html>