<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

$conn = new mysqli("localhost", "test", "test", "projetpixelwar");

$data = json_decode(file_get_contents('php://input'), true);
//association des variables après le passage
$grille_id = $conn->real_escape_string($data['grille_id']);
$position_x = $conn->real_escape_string($data['position_x']);
$position_y = $conn->real_escape_string($data['position_y']);
$couleur = $conn->real_escape_string($data['couleur']);
$proprietaire_id = $_SESSION['user_id'];


//requete sql insertion des pixels dans la bdd
$sql = "INSERT INTO `pixel` (`grille_id`, `position_x`, `position_y`, `couleur`, `proprietaire_id`)
        VALUES ('$grille_id', '$position_x', '$position_y', '$couleur', '$proprietaire_id')
        ON DUPLICATE KEY UPDATE couleur='$couleur', proprietaire_id='$proprietaire_id', date_derniere_modification=CURRENT_TIMESTAMP";


if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error, 'sql' => $sql]);
}

$conn->close();
?>
